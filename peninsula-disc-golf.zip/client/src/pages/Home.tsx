// ============================================================
// Home Page — Peninsula Disc Golf Club
// Design: Outdoor Adventure Editorial
// Sections: Hero, Stats, Upcoming Events, Mission, Blog Preview, CTA
// ============================================================

import { useRef, useEffect } from "react";
import { Link } from "wouter";
import { ArrowRight, Calendar, Users, TreePine, Award, ChevronRight } from "lucide-react";
import { events, blogPosts, categoryColors, categoryLabels, formatShortDate } from "@/lib/data";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";

const HERO_IMAGE = "https://d2xsxph8kpxj0f.cloudfront.net/310519663521680723/4LmVc63AAJJPPDnm7ZNEvC/hero-disc-golf-cpKRzEWvR94HpCwcFp4WBw.webp";
const ACTION_IMAGE = "https://d2xsxph8kpxj0f.cloudfront.net/310519663521680723/4LmVc63AAJJPPDnm7ZNEvC/action-throw-8i7pxpEA3rThZDTMFnR7Xm.webp";
const COMMUNITY_IMAGE = "https://d2xsxph8kpxj0f.cloudfront.net/310519663521680723/4LmVc63AAJJPPDnm7ZNEvC/community-event-D6xB3opW72GX3UimDuQH5d.webp";

const upcomingEvents = events.slice(0, 3);
const featuredPosts = blogPosts.filter((p) => p.featured).slice(0, 3);

const stats = [
  { icon: Users, value: "320+", label: "Active Members" },
  { icon: TreePine, value: "3", label: "Local Courses" },
  { icon: Calendar, value: "40+", label: "Events Per Year" },
  { icon: Award, value: "12", label: "Years of Service" },
];

function useReveal() {
  const ref = useRef<HTMLElement>(null);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const obs = new IntersectionObserver(
      ([entry]) => { if (entry.isIntersecting) { el.classList.add("revealed"); obs.unobserve(el); } },
      { threshold: 0.1 }
    );
    obs.observe(el);
    return () => obs.disconnect();
  }, []);
  return ref;
}

export default function Home() {
  const eventsRef = useReveal();
  const missionRef = useReveal();
  const blogRef = useReveal();

  return (
    <div className="min-h-screen flex flex-col bg-[oklch(0.97_0.015_85)]">
      <Navbar />

      {/* ── HERO ── */}
      <section className="relative min-h-screen flex items-end overflow-hidden">
        <div
          className="absolute inset-0 bg-cover bg-center"
          style={{ backgroundImage: `url(${HERO_IMAGE})` }}
        />
        <div className="absolute inset-0 bg-gradient-to-t from-[oklch(0.12_0.04_55)/0.92] via-[oklch(0.12_0.04_55)/0.45] to-transparent" />

        <div className="relative z-10 container pb-20 pt-32">
          <div className="max-w-3xl">
            <div className="inline-flex items-center gap-2 mb-5">
              <span className="event-tag bg-[oklch(0.65_0.16_48)] text-white">Non-Profit · Est. 2014</span>
            </div>
            <h1 className="font-display text-5xl md:text-7xl font-semibold text-white leading-tight mb-6 animate-fade-up">
              Disc Golf on the{" "}
              <span className="italic text-[oklch(0.82_0.14_48)]">Peninsula</span>
            </h1>
            <p className="font-body text-lg md:text-xl text-white/80 max-w-xl mb-8 animate-fade-up animate-fade-up-delay-1">
              A community-driven non-profit bringing players of all skill levels together through tournaments, leagues, clinics, and course stewardship.
            </p>
            <div className="flex flex-wrap gap-4 animate-fade-up animate-fade-up-delay-2">
              <Link
                href="/events"
                className="inline-flex items-center gap-2 px-7 py-3.5 bg-[oklch(0.65_0.16_48)] hover:bg-[oklch(0.52_0.16_48)] text-white font-body font-bold rounded transition-colors text-sm"
              >
                View Events <ArrowRight className="w-4 h-4" />
              </Link>
              <Link
                href="/about"
                className="inline-flex items-center gap-2 px-7 py-3.5 bg-white/15 hover:bg-white/25 text-white font-body font-bold rounded transition-colors text-sm backdrop-blur-sm border border-white/20"
              >
                Our Mission
              </Link>
            </div>
          </div>
        </div>

        <div className="absolute bottom-8 right-8 z-10 hidden md:flex flex-col items-center gap-2 text-white/40">
          <div className="w-px h-12 bg-white/20" />
          <span className="font-mono-brand text-[10px] tracking-widest uppercase">Scroll</span>
        </div>
      </section>

      {/* ── STATS STRIP ── */}
      <section className="bg-[oklch(0.22_0.04_55)] py-10">
        <div className="container">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {stats.map(({ icon: Icon, value, label }) => (
              <div key={label} className="flex flex-col items-center text-center gap-2">
                <Icon className="w-6 h-6 text-[oklch(0.65_0.16_48)]" />
                <span className="font-display text-3xl font-semibold text-white">{value}</span>
                <span className="font-mono-brand text-[10px] tracking-widest uppercase text-white/50">{label}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── UPCOMING EVENTS ── */}
      <section ref={eventsRef as React.RefObject<HTMLElement>} className="py-20 topo-bg reveal-on-scroll">
        <div className="container">
          <div className="flex items-end justify-between mb-10">
            <div>
              <p className="font-mono-brand text-[11px] tracking-widest uppercase text-[oklch(0.65_0.16_48)] mb-2">On the Calendar</p>
              <h2 className="font-display text-4xl font-semibold text-[oklch(0.22_0.04_55)]">Upcoming Events</h2>
            </div>
            <Link href="/events" className="hidden md:inline-flex items-center gap-1 font-body text-sm font-bold text-[oklch(0.48_0.09_152)] hover:text-[oklch(0.36_0.09_152)] transition-colors">
              Full Calendar <ChevronRight className="w-4 h-4" />
            </Link>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {upcomingEvents.map((event, i) => (
              <Link key={event.id} href={`/events/${event.id}`}>
                <article
                  className={`group bg-white rounded-lg overflow-hidden shadow-sm hover:shadow-md transition-all duration-300 hover:-translate-y-1 cursor-pointer h-full flex flex-col reveal-on-scroll reveal-delay-${i + 1}`}
                >
                  {event.image && (
                    <div className="h-48 overflow-hidden">
                      <img
                        src={event.image}
                        alt={event.title}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                      />
                    </div>
                  )}
                  <div className="p-5 flex flex-col flex-1">
                    <div className="flex items-center justify-between mb-3">
                      <span className={`event-tag ${categoryColors[event.category]}`}>
                        {categoryLabels[event.category]}
                      </span>
                      <span className="font-mono-brand text-[10px] text-[oklch(0.52_0.04_55)]">
                        {formatShortDate(event.date)}
                      </span>
                    </div>
                    <h3 className="font-display text-lg font-semibold text-[oklch(0.22_0.04_55)] mb-2 group-hover:text-[oklch(0.48_0.09_152)] transition-colors">
                      {event.title}
                    </h3>
                    <p className="font-body text-sm text-[oklch(0.52_0.04_55)] line-clamp-2 flex-1">
                      {event.description}
                    </p>
                    <div className="mt-4 pt-4 border-t border-[oklch(0.92_0.018_85)] flex items-center justify-between">
                      <span className="font-body text-xs text-[oklch(0.52_0.04_55)]">{event.location}</span>
                      <span className="font-body text-xs font-bold text-[oklch(0.65_0.16_48)]">
                        {event.entryFee || "Free"}
                      </span>
                    </div>
                  </div>
                </article>
              </Link>
            ))}
          </div>

          <div className="mt-8 text-center md:hidden">
            <Link href="/events" className="inline-flex items-center gap-1 font-body text-sm font-bold text-[oklch(0.48_0.09_152)] hover:text-[oklch(0.36_0.09_152)] transition-colors">
              View Full Calendar <ChevronRight className="w-4 h-4" />
            </Link>
          </div>
        </div>
      </section>

      {/* ── MISSION SPLIT ── */}
      <section ref={missionRef as React.RefObject<HTMLElement>} className="py-20 bg-[oklch(0.22_0.04_55)] overflow-hidden reveal-on-scroll">
        <div className="container grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div className="relative">
            <div className="rounded-lg overflow-hidden aspect-[4/3]">
              <img
                src={ACTION_IMAGE}
                alt="Disc golfer throwing in a forest"
                className="w-full h-full object-cover"
              />
            </div>
            <div className="absolute -bottom-4 -right-4 w-32 h-32 border-2 border-[oklch(0.65_0.16_48)] rounded-lg opacity-40 hidden lg:block" />
          </div>

          <div>
            <p className="font-mono-brand text-[11px] tracking-widest uppercase text-[oklch(0.65_0.16_48)] mb-3">Who We Are</p>
            <h2 className="font-display text-4xl font-semibold text-white mb-6 leading-tight">
              Growing disc golf,<br />
              <span className="italic text-[oklch(0.82_0.14_48)]">one fairway at a time</span>
            </h2>
            <p className="font-body text-white/70 mb-4 leading-relaxed">
              The Peninsula Disc Golf Club is a 501(c)(3) non-profit organization founded in 2014 with a simple mission: make disc golf accessible, welcoming, and thriving on the Peninsula.
            </p>
            <p className="font-body text-white/70 mb-8 leading-relaxed">
              From maintaining our beloved Bayview Park course to running beginner clinics and youth programs, every dollar we raise stays in the community — building courses, funding events, and putting discs in new hands.
            </p>
            <Link
              href="/about"
              className="inline-flex items-center gap-2 px-6 py-3 bg-[oklch(0.65_0.16_48)] hover:bg-[oklch(0.52_0.16_48)] text-white font-body font-bold rounded transition-colors text-sm"
            >
              Meet the Board <ArrowRight className="w-4 h-4" />
            </Link>
          </div>
        </div>
      </section>

      {/* ── BLOG PREVIEW ── */}
      <section ref={blogRef as React.RefObject<HTMLElement>} className="py-20 bg-[oklch(0.94_0.02_85)] reveal-on-scroll">
        <div className="container">
          <div className="flex items-end justify-between mb-10">
            <div>
              <p className="font-mono-brand text-[11px] tracking-widest uppercase text-[oklch(0.65_0.16_48)] mb-2">Latest Updates</p>
              <h2 className="font-display text-4xl font-semibold text-[oklch(0.22_0.04_55)]">News & Stories</h2>
            </div>
            <Link href="/blog" className="hidden md:inline-flex items-center gap-1 font-body text-sm font-bold text-[oklch(0.48_0.09_152)] hover:text-[oklch(0.36_0.09_152)] transition-colors">
              All Posts <ChevronRight className="w-4 h-4" />
            </Link>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {featuredPosts.map((post, i) => (
              <Link key={post.id} href={`/blog/${post.id}`}>
                <article className={`group bg-white rounded-lg overflow-hidden shadow-sm hover:shadow-md transition-all duration-300 hover:-translate-y-1 cursor-pointer h-full flex flex-col reveal-on-scroll reveal-delay-${i + 1}`}>
                  {post.image && (
                    <div className="h-44 overflow-hidden">
                      <img
                        src={post.image}
                        alt={post.title}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                      />
                    </div>
                  )}
                  <div className="p-5 flex flex-col flex-1">
                    <div className="flex items-center gap-2 mb-3">
                      <span className={`event-tag ${categoryColors[post.category]}`}>
                        {categoryLabels[post.category]}
                      </span>
                    </div>
                    <h3 className="font-display text-base font-semibold text-[oklch(0.22_0.04_55)] mb-2 group-hover:text-[oklch(0.48_0.09_152)] transition-colors line-clamp-2">
                      {post.title}
                    </h3>
                    <p className="font-body text-sm text-[oklch(0.52_0.04_55)] line-clamp-2 flex-1">
                      {post.excerpt}
                    </p>
                    <div className="mt-4 pt-4 border-t border-[oklch(0.92_0.018_85)] flex items-center justify-between">
                      <span className="font-body text-xs text-[oklch(0.52_0.04_55)]">{post.author}</span>
                      <span className="font-mono-brand text-[10px] text-[oklch(0.52_0.04_55)]">
                        {formatShortDate(post.date)}
                      </span>
                    </div>
                  </div>
                </article>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* ── JOIN CTA ── */}
      <section
        className="relative py-24 overflow-hidden"
        style={{
          backgroundImage: `url(${COMMUNITY_IMAGE})`,
          backgroundSize: "cover",
          backgroundPosition: "center",
        }}
      >
        <div className="absolute inset-0 bg-[oklch(0.22_0.04_55)/0.82]" />
        <div className="relative z-10 container text-center max-w-2xl mx-auto">
          <p className="font-mono-brand text-[11px] tracking-widest uppercase text-[oklch(0.65_0.16_48)] mb-3">Become a Member</p>
          <h2 className="font-display text-4xl md:text-5xl font-semibold text-white mb-5 leading-tight">
            Ready to join the community?
          </h2>
          <p className="font-body text-white/70 mb-8 text-lg">
            Annual membership is just $40 for individuals or $60 for families. Members enjoy discounted tournament entry, exclusive events, and the satisfaction of supporting disc golf on the Peninsula.
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <Link
              href="/about"
              className="inline-flex items-center gap-2 px-8 py-4 bg-[oklch(0.65_0.16_48)] hover:bg-[oklch(0.52_0.16_48)] text-white font-body font-bold rounded transition-colors"
            >
              Learn About Membership <ArrowRight className="w-4 h-4" />
            </Link>
            <Link
              href="/events"
              className="inline-flex items-center gap-2 px-8 py-4 bg-white/15 hover:bg-white/25 text-white font-body font-bold rounded transition-colors border border-white/20 backdrop-blur-sm"
            >
              Browse Events
            </Link>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
