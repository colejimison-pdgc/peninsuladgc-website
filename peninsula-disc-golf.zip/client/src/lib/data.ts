// ============================================================
// Peninsula Disc Golf Club — Site Data
// Design: Outdoor Adventure Editorial
// ============================================================

export interface Event {
  id: string;
  title: string;
  date: string;
  time: string;
  location: string;
  category: "tournament" | "league" | "clinic" | "doubles" | "volunteer";
  description: string;
  longDescription: string;
  registrationUrl?: string;
  registrationLabel?: string;
  directionsUrl?: string;
  customDateDisplay?: string;
  maxPlayers?: number;
  entryFee?: string;
  divisions?: string[];
  image?: string;
  featured?: boolean;
}

export interface BoardMember {
  id: string;
  name: string;
  title: string;
  bio: string;
  yearsServing?: string;
  avatar?: string;
}

export interface BlogPost {
  id: string;
  title: string;
  date: string;
  author: string;
  category: "news" | "tournament-recap" | "course-update" | "community" | "tips";
  excerpt: string;
  content: string;
  image?: string;
  featured?: boolean;
}

export const events: Event[] = [
  {
    id: "spring-league",
    title: "Tuesday / Thursday Spring Season",
    date: "2026-03-10",
    time: "Flex start",
    location: "Emerald Hills Disc Golf Course, Redwood City",
    category: "league",
    description: "Flex start league every Tuesday and Thursday. All skill levels welcome. Play solo or in groups.",
    longDescription: `Every Tuesday and Thursday there is a flex start league at the Emerald Hills Disc Golf Course in Redwood City. It's the perfect way to meet fellow disc golfers, improve your game, and enjoy a beautiful and well-maintained course.\n\nFormat: Flex start, meaning play anytime during the day. You are able to play in this league solo and be eligible for the league payouts. You must play in a group of 3 or more to be eligible for the ace pot.\n\nCost:\nBag tag: $25/year (also gets you discounted greens fees)\nLeague fee: $5 per round\nAce pot: $1 per round (optional)`,
    entryFee: "$5 league + $10 green fees (with bag tag)",
    registrationUrl: "https://udisc.com/events?courseId=9gK8YyTJsy3wBMwNX&quickFilter=league",
    registrationLabel: "Udisc Event",
    directionsUrl: "https://maps.app.goo.gl/jCxhowx5SmVsJvvE6",
    customDateDisplay: "Tuesdays and Thursdays from March 10 to June 11, 2026",
    image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663521680723/4LmVc63AAJJPPDnm7ZNEvC/action-throw-8i7pxpEA3rThZDTMFnR7Xm.webp",
    featured: true,
  },
  {
    id: "monday-doubles",
    title: "Monday Doubles League",
    date: "2026-03-23",
    time: "5:00 PM",
    location: "Villa Maria Disc Golf Course, Cupertino",
    category: "doubles",
    description: "Weekly Doubles league every Monday. All skill levels welcome. Play in pairs and compete for weekly prizes.",
    longDescription: `The Monday Doubles league is a great opportunity to meet up with a great community of disc golfers in a more casual format. Fun is guaranteed.\n\nDivisions:\n\nCompetitive Division: Join to get paired with a partner to compete for the full payout of the $5 entry fee from each competitor.\n\nRecreation Division: Play for free with a partner that you bring or get paired with another person in the division.\n\nFees:\nCompetitive Division: $5 per round\nRecreation Division: Free\nDaily parking pass: $6 per car\nAce pot: $1 per round (optional)`,
    entryFee: "$5 (Competitive) or Free (Recreation) + $6 parking",
    divisions: ["Competitive", "Recreation"],
    registrationUrl: "https://udisc.com/events?courseId=Ju4Aqz5FFNoinH4ZA&quickFilter=league",
    registrationLabel: "Udisc Event",
    directionsUrl: "https://maps.app.goo.gl/a3NoNVeX1eCMUioi7",
    customDateDisplay: "Mondays from March 23 to September 14, 2026",
    image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663521680723/4LmVc63AAJJPPDnm7ZNEvC/action-throw-8i7pxpEA3rThZDTMFnR7Xm.webp",
    featured: true,
  },
];

export const boardMembers: BoardMember[] = [
  {
    id: "president",
    name: "Sarah Whitmore",
    title: "President",
    bio: "Sarah has been playing disc golf for over 15 years and has been instrumental in establishing three new courses on the Peninsula. She brings a background in non-profit management and a deep passion for growing the sport in our community.",
    yearsServing: "2019 – Present",
  },
  {
    id: "vice-president",
    name: "Marcus Chen",
    title: "Vice President",
    bio: "Marcus is a PDGA-certified tournament director with experience running regional and national-level events. He oversees our tournament program and works closely with parks departments to secure and maintain course permits.",
    yearsServing: "2021 – Present",
  },
  {
    id: "treasurer",
    name: "Linda Okafor",
    title: "Treasurer",
    bio: "Linda brings 20 years of financial management experience to the club. She manages our annual budget, grant applications, and ensures our non-profit status remains in good standing. She is also an avid recreational player.",
    yearsServing: "2020 – Present",
  },
  {
    id: "secretary",
    name: "Tom Reyes",
    title: "Secretary",
    bio: "Tom handles club communications, meeting minutes, and membership records. A retired teacher, he also leads our youth outreach program that introduces disc golf to local schools and after-school programs.",
    yearsServing: "2022 – Present",
  },
  {
    id: "course-director",
    name: "Priya Nair",
    title: "Course Director",
    bio: "Priya coordinates all course maintenance, improvement projects, and new course development. She has a background in landscape architecture and has designed two of the club's most beloved holes at Bayview Park.",
    yearsServing: "2021 – Present",
  },
  {
    id: "events-coordinator",
    name: "Jake Sullivan",
    title: "Events Coordinator",
    bio: "Jake organizes the club's full calendar of events, from weekly leagues to our flagship tournaments. His energy and attention to detail have made Peninsula events some of the most well-run in the region.",
    yearsServing: "2023 – Present",
  },
];

export const blogPosts: BlogPost[] = [
  {
    id: "spring-open-preview-2026",
    title: "Everything You Need to Know About the 2026 Peninsula Spring Open",
    date: "2026-04-01",
    author: "Marcus Chen",
    category: "news",
    excerpt: "The 12th annual Peninsula Spring Open is just weeks away. Here's a complete guide to registration, divisions, the course layout, and what to expect on event day.",
    content: `The Peninsula Spring Open is the highlight of our spring calendar, and the 2026 edition promises to be the best yet. Registration is now open and filling fast — we've already received over 80 registrations in the first week.\n\nThis year we've made several improvements based on player feedback from 2025. The tee pads on holes 7 and 14 have been resurfaced, new signage has been installed throughout the course, and we've added a dedicated spectator area near the 18th basket with seating and refreshments.\n\nDivisions are open for Recreational, Intermediate, Advanced, Masters 40+, and Women's Open. Entry fee is $35 per player, which includes a player pack with a commemorative disc, tournament scorecard, and lunch voucher.\n\nRegistration closes April 14th or when divisions fill. Register early to secure your spot!`,
    image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663521680723/4LmVc63AAJJPPDnm7ZNEvC/community-event-D6xB3opW72GX3UimDuQH5d.webp",
    featured: true,
  },
  {
    id: "bayview-hole-renovation",
    title: "Bayview Park Holes 7 & 14 Renovation Complete",
    date: "2026-03-22",
    author: "Priya Nair",
    category: "course-update",
    excerpt: "After months of planning and two weekends of volunteer work, the renovated tee pads and improved basket placements on holes 7 and 14 are now open for play.",
    content: `We're thrilled to announce that the renovation of holes 7 and 14 at Bayview Park is complete and open for play. This project has been in the works since last fall, when our Course Committee identified these two holes as priorities for improvement.\n\nHole 7 now features a new concrete tee pad with a more challenging angle toward the basket, adding strategic interest to what was previously a straightforward hole. The basket has been moved 30 feet further back, extending the hole from 280 feet to 340 feet.\n\nHole 14 received a complete tee pad overhaul with a new elevated platform that offers a stunning view of the bay. The approach has been cleared of overgrown brush, opening up a new line for skilled players.\n\nThank you to the 23 volunteers who gave their weekends to make this happen, and to our sponsors whose contributions funded the materials.`,
    image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663521680723/4LmVc63AAJJPPDnm7ZNEvC/course-scenic-f5bzDYBHMESqz9UzBZnzrH.webp",
    featured: true,
  },
  {
    id: "youth-program-launch",
    title: "PDGC Youth Program Launches at Three Peninsula Schools",
    date: "2026-03-10",
    author: "Tom Reyes",
    category: "community",
    excerpt: "Our new after-school disc golf program is now active at Bayview Middle School, Peninsula High, and Harborview Elementary, reaching over 60 young players.",
    content: `The Peninsula Disc Golf Club is proud to announce the launch of our Youth Disc Golf Program at three local schools this spring semester. This initiative, two years in the making, brings structured disc golf instruction to students in grades 4 through 10.\n\nAt each school, certified instructors lead weekly 45-minute sessions covering throwing fundamentals, rules, etiquette, and fitness. Each participating student receives a starter disc set courtesy of our club sponsors.\n\nThe program has been met with tremendous enthusiasm — all three schools filled their program slots within days of announcement. We're already in talks with two additional schools for the fall semester.\n\nIf your school is interested in participating, or if you'd like to volunteer as an instructor, please contact Tom Reyes at education@pdgc.example.com.`,
    image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663521680723/4LmVc63AAJJPPDnm7ZNEvC/community-event-D6xB3opW72GX3UimDuQH5d.webp",
  },
  {
    id: "disc-selection-tips",
    title: "Choosing Your First Disc: A Beginner's Guide",
    date: "2026-02-28",
    author: "Jake Sullivan",
    category: "tips",
    excerpt: "Walking into a disc golf shop for the first time can be overwhelming. Here's a straightforward guide to help new players choose the right discs to start their journey.",
    content: `One of the most common questions we hear from new players is: "Which disc should I buy?" With hundreds of options on the market, it's easy to feel overwhelmed. Here's our simple guide to getting started.\n\nFor beginners, we recommend starting with just three discs: a putter, a mid-range, and a fairway driver. Resist the urge to buy a distance driver right away — they require significant arm speed to fly correctly and often cause frustration for newer players.\n\nFor a putter, look for something with a comfortable grip and a straight flight path. The Innova Aviar and Discraft Banger GT are perennial favorites. For a mid-range, the Innova Mako3 or Discraft Buzzz are excellent choices that fly predictably. For a fairway driver, consider the Innova Leopard or Dynamic Discs Escape.\n\nMost importantly, visit your local disc golf shop and ask to hold the discs before buying. Comfort in the hand matters as much as flight characteristics.`,
    image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663521680723/4LmVc63AAJJPPDnm7ZNEvC/action-throw-8i7pxpEA3rThZDTMFnR7Xm.webp",
  },
  {
    id: "winter-league-recap",
    title: "2025–2026 Winter League Wrap-Up",
    date: "2026-02-15",
    author: "Jake Sullivan",
    category: "tournament-recap",
    excerpt: "The winter league wrapped up with 48 dedicated players braving the elements every Saturday morning. Congratulations to our division champions!",
    content: `Despite the wet and windy conditions that define Peninsula winters, our 2025–2026 Winter League was a tremendous success. Forty-eight players showed up week after week, rain or shine, for 14 weeks of Saturday morning competition at Peninsula Community Park.\n\nDivision Champions: Open Division — Ryan Kowalski (averaging 52 points per round). Women's Division — Aisha Patel (averaging 48 points). Masters 40+ — Dave Thornton (averaging 50 points). Recreational — Sam Liu (most improved player award).\n\nSpecial recognition goes to the six players who achieved perfect attendance across all 14 rounds: Ryan Kowalski, Dave Thornton, Aisha Patel, Carlos Mendez, Beth Yamamoto, and Frank O'Brien. You are the heart of this club.\n\nSee you all at the Spring Open!`,
    image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663521680723/4LmVc63AAJJPPDnm7ZNEvC/course-scenic-f5bzDYBHMESqz9UzBZnzrH.webp",
  },
  {
    id: "new-course-grant",
    title: "PDGC Awarded $15,000 Grant for New Course Development",
    date: "2026-01-30",
    author: "Sarah Whitmore",
    category: "news",
    excerpt: "The Peninsula Disc Golf Club has been awarded a significant grant from the Regional Parks Foundation to fund the design and installation of a new 9-hole course.",
    content: `We are overjoyed to announce that the Peninsula Disc Golf Club has been awarded a $15,000 grant from the Regional Parks Foundation's Community Recreation Initiative. This grant will fund the design and installation of a new 9-hole disc golf course at Hillside Nature Reserve.\n\nThe Hillside course has been a dream of our club for over five years. The terrain offers incredible variety — wooded corridors, open meadows, and elevation changes that will challenge and delight players of all skill levels.\n\nCourse Director Priya Nair will lead the design process, with community input sessions planned for February and March. Construction is expected to begin in late spring, with a grand opening celebration planned for late summer 2026.\n\nThank you to the Regional Parks Foundation and to every club member whose dues and event participation made this grant application possible.`,
    image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663521680723/4LmVc63AAJJPPDnm7ZNEvC/about-banner-XUFxTxxrgNTCiHnwjQMSdz.webp",
    featured: false,
  },
];

export const categoryColors: Record<string, string> = {
  tournament: "bg-amber-100 text-amber-800",
  league: "bg-green-100 text-green-800",
  clinic: "bg-blue-100 text-blue-800",
  doubles: "bg-indigo-100 text-indigo-800",
  volunteer: "bg-orange-100 text-orange-800",
  news: "bg-red-100 text-red-800",
  "tournament-recap": "bg-amber-100 text-amber-800",
  "course-update": "bg-green-100 text-green-800",
  community: "bg-blue-100 text-blue-800",
  tips: "bg-teal-100 text-teal-800",
};

export const categoryLabels: Record<string, string> = {
  tournament: "Tournament",
  league: "League",
  clinic: "Clinic",
  doubles: "Doubles",
  volunteer: "Volunteer",
  news: "News",
  "tournament-recap": "Recap",
  "course-update": "Course Update",
  community: "Community",
  tips: "Tips & Technique",
};

export function formatDate(dateStr: string): string {
  const date = new Date(dateStr + "T12:00:00");
  return date.toLocaleDateString("en-US", {
    weekday: "long",
    year: "numeric",
    month: "long",
    day: "numeric",
  });
}

export function formatShortDate(dateStr: string): string {
  const date = new Date(dateStr + "T12:00:00");
  return date.toLocaleDateString("en-US", {
    month: "short",
    day: "numeric",
    year: "numeric",
  });
}
