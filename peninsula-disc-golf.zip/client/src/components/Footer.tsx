// ============================================================
// Footer — Peninsula Disc Golf Club
// Design: Outdoor Adventure Editorial — Dark espresso bg
// ============================================================

import { Link } from "wouter";
import { Disc, Mail, MapPin, Facebook, Instagram } from "lucide-react";

export default function Footer() {
  return (
    <footer className="bg-[oklch(0.18_0.04_55)] text-white/80">
      {/* Main footer content */}
      <div className="container py-14 grid grid-cols-1 md:grid-cols-3 gap-10">
        {/* Brand column */}
        <div>
          <div className="flex items-center gap-2 mb-4">
            <div className="w-9 h-9 rounded-full bg-[oklch(0.65_0.16_48)] flex items-center justify-center flex-shrink-0">
              <Disc className="w-5 h-5 text-white" strokeWidth={2} />
            </div>
            <div className="leading-tight">
              <div className="font-display font-semibold text-white text-sm leading-none">Peninsula</div>
              <div className="font-mono-brand text-[oklch(0.65_0.16_48)] text-[10px] tracking-widest uppercase leading-none mt-0.5">Disc Golf Club</div>
            </div>
          </div>
          <p className="font-body text-sm leading-relaxed text-white/60 max-w-xs">
            A non-profit organization dedicated to growing disc golf on the Peninsula — through community events, course stewardship, and youth outreach.
          </p>
          <div className="flex gap-3 mt-5">
            <a href="#" className="w-9 h-9 rounded-full bg-white/10 hover:bg-[oklch(0.65_0.16_48)] flex items-center justify-center transition-colors" aria-label="Facebook">
              <Facebook className="w-4 h-4" />
            </a>
            <a href="#" className="w-9 h-9 rounded-full bg-white/10 hover:bg-[oklch(0.65_0.16_48)] flex items-center justify-center transition-colors" aria-label="Instagram">
              <Instagram className="w-4 h-4" />
            </a>
          </div>
        </div>

        {/* Quick Links */}
        <div>
          <h4 className="font-display font-semibold text-white text-base mb-4">Quick Links</h4>
          <ul className="space-y-2">
            {[
              { href: "/", label: "Home" },
              { href: "/events", label: "Events Calendar" },
              { href: "/about", label: "About the Club" },
              { href: "/about#board", label: "Board Members" },
              { href: "/blog", label: "News & Blog" },
            ].map((link) => (
              <li key={link.href}>
                <Link href={link.href} className="font-body text-sm text-white/60 hover:text-[oklch(0.65_0.16_48)] transition-colors">
                  {link.label}
                </Link>
              </li>
            ))}
          </ul>
        </div>

        {/* Contact */}
        <div>
          <h4 className="font-display font-semibold text-white text-base mb-4">Contact Us</h4>
          <ul className="space-y-3">
            <li className="flex items-start gap-2 font-body text-sm text-white/60">
              <MapPin className="w-4 h-4 mt-0.5 text-[oklch(0.65_0.16_48)] flex-shrink-0" />
              <span>Bayview Park, Peninsula, WA 98000</span>
            </li>
            <li className="flex items-center gap-2 font-body text-sm text-white/60">
              <Mail className="w-4 h-4 text-[oklch(0.65_0.16_48)] flex-shrink-0" />
              <a href="mailto:info@pdgc.example.com" className="hover:text-[oklch(0.65_0.16_48)] transition-colors">
                info@pdgc.example.com
              </a>
            </li>
          </ul>
          <div className="mt-5 p-3 rounded bg-white/5 border border-white/10">
            <p className="font-mono-brand text-[10px] tracking-widest uppercase text-white/40 mb-1">PDGA Club #</p>
            <p className="font-display text-white font-semibold">C12345</p>
          </div>
        </div>
      </div>

      {/* Bottom bar */}
      <div className="border-t border-white/10">
        <div className="container py-4 flex flex-col sm:flex-row items-center justify-between gap-2">
          <p className="font-body text-xs text-white/40">
            © {new Date().getFullYear()} Peninsula Disc Golf Club. A 501(c)(3) Non-Profit Organization.
          </p>
          <p className="font-mono-brand text-[10px] text-white/30 tracking-wide">
            Made with ♥ for the disc golf community
          </p>
        </div>
      </div>
    </footer>
  );
}
